package download;

/**
 * Created by jmf on 2017/4/13 0013.
 */

public class MyFileDownloadCallback {
    public void onStart() {
    }

    public void onProgress(int progress, long total, long sum) {
    }

    public void onFailure() {
    }

    public void onDone() {
    }

}
